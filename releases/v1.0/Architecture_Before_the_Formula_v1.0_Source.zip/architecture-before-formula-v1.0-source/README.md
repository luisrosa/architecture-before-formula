# Architecture Before the Formula v1.0 - source package

This archive contains the complete LaTeX source for:

**Architecture Before the Formula: Receiver-Wise Factorization and the Reconstruction of Transformer Blocks**

It excludes compiled PDFs, generated LaTeX products, release artifacts, Git history, and CI-only files.

## Build

Requirements:

- `latexmk`
- `pdflatex`
- `bibtex` or `bibtex8`
- a standard TeX Live scientific installation

From the package root:

```bash
bash ./build.sh
```

The compiled article and supplement are written to `.build/output/`.

The compiled v1.0 PDFs and release checksums are distributed separately with the GitHub release.
